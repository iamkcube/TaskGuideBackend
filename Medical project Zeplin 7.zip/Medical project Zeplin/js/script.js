const sidebar = document.querySelector(".container");
const transparentBg=document.querySelector(".transparent-bg");
const primaryBtn = document.querySelector(".primary-btn");
const closeBtn = document.querySelector(".close-btn");

function openSidebar(){
	sidebar.classList.add("open");
	transparentBg.classList.add("active");
}
function closeSidebar(){
	sidebar.classList.remove("open");
	transparentBg.classList.remove("active");
}

primaryBtn.addEventListener("click",openSidebar);
closeBtn.addEventListener("click",closeSidebar);
transparentBg.addEventListener("click",closeSidebar);